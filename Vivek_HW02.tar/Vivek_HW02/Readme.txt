Distro used: Ubuntu 18.04
Kernel version: 5.3