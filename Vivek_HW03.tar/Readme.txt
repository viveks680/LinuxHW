Distro: Ubuntu 18.04
Compiled kernel: 5.5.5 (latest stable)

In syslog, name given within each function "Vivek Senapati" or "Vivek"