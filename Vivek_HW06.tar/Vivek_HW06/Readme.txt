Distro: Ubuntu 18.04
Compiled kernel: 5.5

In syslog, name given within each function "Vivek Senapati"
In Syslogs, custom kernel threads are pid 215 and 216